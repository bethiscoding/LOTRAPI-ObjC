//
//  BRMCharactersTableViewController.swift
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class BRMCharactersTableViewController: UITableViewController {

    // MARK: - Outlets & Properties
    
    var characters: [BRMCharacter] = [] {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        BRMCharacterController .fetchCharacters { (characters, error) in
            self.characters = characters
        }
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return characters.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CharacterCell", for: indexPath) as? BRMCharacterTableViewCell else { return UITableViewCell() }

        let character = characters[indexPath.row]
        cell.character = character
        
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

} //End
