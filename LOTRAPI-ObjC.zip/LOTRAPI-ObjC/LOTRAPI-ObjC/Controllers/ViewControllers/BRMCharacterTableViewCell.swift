//
//  BRMCharacterTableViewCell.swift
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class BRMCharacterTableViewCell: UITableViewCell {

    // MARK: - Outlets & Properties
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var raceLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var realmLabel: UILabel!
    
    var character: BRMCharacter? {
        didSet {
            updateViews()
        }
    }
    
    // MARK: - Methods
    
    func updateViews() {
        guard let character = character else { return }
        nameLabel.text = character.name
        raceLabel.text = character.race
        genderLabel.text = character.gender
        realmLabel.text = character.realm
    }
    
} //End
