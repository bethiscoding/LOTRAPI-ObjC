//
//  BRMCharacterController.m
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import "BRMCharacterController.h"

static NSString * const baseURLString = @"https://the-one-api.herokuapp.com/v1";
static NSString * const charactersComp = @"character";
static NSString * const APIKey = @"Bearer Lxd231S5ksrFRqvnAQrp";


@implementation BRMCharacterController

+ (void)fetchCharacters:(void (^)(NSArray<BRMCharacter *> * _Nullable, NSError * _Nullable))completion
{
    NSURL *baseURL = [NSURL URLWithString:baseURLString];
    NSURL *charactersURL = [baseURL URLByAppendingPathComponent:charactersComp];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:charactersURL];
    [request addValue:APIKey forHTTPHeaderField:@"Authorization"];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error)
        {
            NSLog(@"There was an error in %s: %@, %@", __PRETTY_FUNCTION__, error, [error localizedDescription]);
            completion(nil, error);
            return;
        }
        
        if (response)
        {
            NSLog(@"%@", response);
        }
        
        if (data)
        {
            NSDictionary *topLevelDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
            NSArray *docsArray = topLevelDictionary[@"docs"];
            
            NSMutableArray *characters = [NSMutableArray array];
            for (NSDictionary *dictionary in docsArray)
            {
                BRMCharacter *character = [[BRMCharacter alloc] initWithDictionary:dictionary];
                [characters addObject:character];
            }
            
            if (!topLevelDictionary)
            {
                NSLog(@"Error parsing the JSON: %@", error);
                completion(nil, error);
                return;
            }
            
            completion(characters, nil);
        }
    }] resume];
}

@end
