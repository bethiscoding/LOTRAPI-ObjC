//
//  BRMCharacterController.h
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BRMCharacter.h"

NS_ASSUME_NONNULL_BEGIN

@interface BRMCharacterController : NSObject

+(void)fetchCharacters:(void(^) (NSArray<BRMCharacter *> *characters, NSError *error))completion;

@end

NS_ASSUME_NONNULL_END
