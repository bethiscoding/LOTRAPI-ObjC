//
//  SceneDelegate.h
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

