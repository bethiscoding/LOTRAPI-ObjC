//
//  BRMCharacter.m
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import "BRMCharacter.h"

@implementation BRMCharacter

- (instancetype)initWithName:(NSString *)name race:(NSString *)race gender:(NSString *)gender realm:(NSString *)realm
{
    self = [super init];
    
    if (self)
    {
        _name = name;
        _race = race;
        _gender = gender;
        _realm = realm;
    }
    return self;
}

@end

@implementation BRMCharacter (JSONConvertible)

-(instancetype)initWithDictionary:(NSDictionary<NSString *, id> *)dictionary;
{
    NSString *name = dictionary[@"name"];
    NSString *race = dictionary[@"race"];
    NSString *gender = dictionary[@"gender"];
    NSString *realm = dictionary[@"realm"];

    return [self initWithName:name race:race gender:gender realm:realm];
}

@end
