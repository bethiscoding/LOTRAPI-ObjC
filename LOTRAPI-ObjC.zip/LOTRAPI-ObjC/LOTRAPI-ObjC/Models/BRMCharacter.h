//
//  BRMCharacter.h
//  LOTRAPI-ObjC
//
//  Created by Bethany Morris on 5/7/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BRMCharacter : NSObject

@property (nonatomic, readonly, copy) NSString *name;
@property (nonatomic, readonly, copy) NSString *race;
@property (nonatomic, readonly, copy) NSString *gender;
@property (nonatomic, readonly, copy) NSString *realm;

-(instancetype)initWithName:(NSString *)name
                       race:(NSString *)race
                     gender:(NSString *)gender
                      realm:(NSString *)realm;

@end

@interface BRMCharacter (JSONConvertible)

-(instancetype)initWithDictionary:(NSDictionary<NSString *, id> *)dictionary;

@end

NS_ASSUME_NONNULL_END
